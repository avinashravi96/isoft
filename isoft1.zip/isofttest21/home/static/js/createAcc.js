$("#submit").validate({
        rules: {
            first_name: "required",
                
            last_name :"required",
                
            phone : {
                required : true,
                minlength : 10
            }
            cemail: {
                required: true,
                email:true
            },
            pass: {
				required: true,
				minlength: 5
			},
			confirm_pass: {
				required: true,
				minlength: 5,
				equalTo: "#pass"
			},
			// curl: {
   //              required: true,
   //              url:true
   //          },
   //          crole:"required",
   //          ccomment: {
			// 	required: true,
			// 	minlength: 15
   //          },
   //          cgender:"required",
			// cagree:"required",
        },
        //For custom messages
        messages: {
            first_name:{
                required: "Enter the First Name",
                // minlength: "Enter at least 5 characters"
            },
            last_name:{
                required: "Enter the Last Name",
                // minlength: "Enter at least 5 characters"
            },
            phone:{
                required: "Enter the Phone Number",
                minlength: "Enter the ten digit phone Number"
            },
            
            // curl: "Enter your website",
        },
        errorElement : 'div',
        errorPlacement: function(error, element) {
          var placement = $(element).data('error');
          if (placement) {
            $(placement).append(error)
          } else {
            error.insertAfter(element);
          }
        }
     });