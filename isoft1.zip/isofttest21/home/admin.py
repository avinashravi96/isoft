from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(OTP)
admin.site.register(User_info)
admin.site.register(Hire_user)
admin.site.register(Trainer_info)
admin.site.register(RequirementsPosts)
admin.site.register(proposals)
admin.site.register(Skills)
admin.site.register(Interests)
admin.site.register(Trainer_Skills)
admin.site.register(Trainer_keys)
admin.site.register(Testimonials)
admin.site.register(JobHistory)
admin.site.register(Issue)
admin.site.register(Grievances)
admin.site.register(Invoice)

