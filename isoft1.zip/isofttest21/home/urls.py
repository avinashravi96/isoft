from django.conf.urls import url
from .import views
from django.views.generic.base import TemplateView

urlpatterns = [
    url(r'^$', TemplateView.as_view(template_name='isoft-index.html'),name='isoft-index'),
	#url(r'^$',views.index,name = 'isoft-index'),
	url(r'^isoft/signup$',views.signup,name = 'signup'),
    url(r'^isoft-invoice$',views.invoice,name = 'invoice'),
	url(r'^trainers_signup$',views.trainer_signup,name = 'trainerssignup'),
	url(r'^hire_signup$',views.hire_signup,name = 'hiresignup'),
	url(r'^login$',views.user_login,name = 'login'),
	url(r'^verify$',views.trainer_verify,name = 'trainer_verify'),
	url(r'^verify_hire$',views.verify_hire,name = 'verify_hire'),
	url(r'^printInvoice$',views.printInvoice,name = 'printInvoice'),
	url(r'^createInvoice$',views.createInvoice,name = 'createInvoice'),



	url(r'^validate$',views.validate,name = 'validate'),
	url(r'^train_validate$',views.train_validate,name = 'trainvalidate'),
	url(r'^hire_validate$',views.hire_validate,name = 'hirevalidate'),
	# url(r'validate$',views.validate,name = 'validate'),
	

	url(r'^train_createuser$',views.train_createuser,name = 'traincreateuser'),
	url(r'^hire_createuser$',views.hire_createuser,name = 'hirecreateuser'),
	url(r'createuser$',views.hire_createuser,name = 'hirecreateuser'),


	url(r'^userValidate$',views.userValidate,name = 'userValidate'),
	url(r'^trainer$',views.trainer,name = 'trainerdash'),
	url(r'^hire$',views.hire,name = 'hiredash'),
	
	url(r'^postreq$',views.postreq,name = 'postreq'),


	url(r'^train_registration$',views.train_registration,name = 'registration'),
	url(r'^hire_registration$',views.hire_registration,name = 'registration'),

	url(r'^propose$',views.propose,name = 'propose'),	

	url(r'^isoft-logout$',views.user_logout,name = 'userlogout'),	

	url(r'^ui$',views.ui,name = 'ui'),

	url(r'^skills$',views.skills,name = 'skills'),		
	url(r'^updateprofile$',views.updateprofile,name = 'updateprofile'),
	url(r'^addskill$',views.addskill,name = 'addskill'),
	url(r'^updateHireprofile$',views.updateHireprofile,name = 'updateHireprofile'),		
	url(r'^updateRequirements$',views.updateRequirements,name = 'updateRequirements'),		

	url(r'^dummy$',views.dummy,name = 'dummy'),			

	url(r'^signup$',views.signup,name = 'signup'),
	url(r'^verifyUser$',views.verifyUser,name = 'verifyUser'),
	url(r'^validate$',views.validate,name = 'validate'),
	url(r'^createUser$',views.createUser,name = 'createUser'),

	url(r'^adminpanel$',views.adminpanel,name = 'adminpanel'),			

	# Search
	url(r'^fetchtrainers$',views.fetchtrainers,name = 'fetchtrainers'),			
	url(r'^fetchemployers$',views.fetchemployers,name = 'fetchemployers'),
	url(r'^clearsearch$',views.clearsearch,name = 'clearsearch'),

	url(r'^showinterest$',views.showinterest,name = 'showinterest'),

	#KeyGen - Testimonial
	url(r'^generate_key$',views.generate_key,name = 'generate_key'),
	url(r'^([a-zA-z0-9]{64})$',views.test_regex,name = 'test_regex'),
	url(r'^save_testimonial$',views.save_testimonial,name = 'testimonial'),

	#fullfilled
	url(r'^fullfilled$',views.fullfilled,name = 'fullfilled'),
	url(r'^job_done$',views.job_done,name = 'job_done'),

	#view trainer
	url(r'^trainer([a-zA-z0-9]+)$',views.viewTrainer,name = 'viewTrainer'),
	url(r'^rate$',views.rate,name = 'rate'),
	

	# Hire Trainer
	url(r'^hireTrainer$',views.hireTrainer,name = 'hireTrainer'),

	# tour
	url(r'^tour$',views.tour,name = 'tour'),

	#issue 
	url(r'^issue$',views.issue,name = 'issue'),

	# grievances
	url(r'^grievances$',views.grievances,name = 'grievances'),
	url(r'^auth_grievance$',views.auth_grievance,name = 'auth_grievance'),
	url(r'^submit_grievance$',views.submit_grievance,name = 'submit_grievance'),
	url(r'^isofG([a-zA-Z0-9!@#$%&-_=+]{10})$',views.grievance_status,name = 'grievance_status'),

	url(r'^rateemp$',views.rateemp,name = 'rateemp'),


	
]