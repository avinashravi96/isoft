import datetime
from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
from django.contrib.auth import authenticate, login , logout
from django.contrib.auth.models import User
from django.shortcuts import redirect
from .models import *

#from bs4 import BeautifulSoup
from .forms import *
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
import http.cookiejar as cookielib
# from getpass import getpass
import sys
import smtplib
from django.template.response import TemplateResponse
# from email6.mime.text import MIMEText
# from email6.mime.base import MIMEBase
from .models import *
import random
from django.db.models import Q
from django.utils.crypto import get_random_string
import hashlib

# from Crypto.Cipher import AES
import base64
import re

# def dummy(request):
# 	return render(request,"trainer_acc.html")

def index(request):
	return render(request,"isoft-index.html",{})

def trainer_signup(request):
	return render(request,"trainer_signup.html",{})
def hire_signup(request):
	return render(request,"hire.html",{})

def user_login(request):
	return render(request,"landingpage.html",{})


def trainer_verify(request):
	request.session["first_name"] = request.POST["first_name"]
	request.session["last_name"] = request.POST["last_name"]
	request.session["phone"] = request.POST["phone"]
	request.session["email"] = request.POST["email"]
	request.session["train"] = "true"
	# request.session["skills"] = request.POST["skills"]
	# request.session["experience"] = request.POST["experience"]
	# request.session["language"] = request.POST["language"]
	# request.session["date"] = request.POST["date"]
	# request.session["city"] = request.POST["city"]
	# request.session["address"] = request.POST["address"]
    #r = random.randint(1111,9999)
	#sms_OTP = str(r)

	#r = random.randint(1111,9999)
	#email_OTP = str(r)

	#username = "9962734053"
	#passwd = "ghostfreak"
	#message = sms_OTP
	#number = request.POST["phone"]

	#message = "+".join(message.split(' '))

	#url = 'http://site24.way2sms.com/Login1.action?'
	#data = 'username='+username+'&password='+passwd+'&Submit=Sign+in'
	#data = data.encode('utf-8')

	#cj = cookielib.CookieJar()
	#opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))

	#opener.addheaders = [('User-Agent','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.120 Safari/537.36')]

	#try:
	#    usock = opener.open(url, data)
	#except IOError:
	 #   print ("Error while logging in.")
	 #   sys.exit(1)


	#jession_id = str(cj).split('~')[1].split(' ')[0]
	#send_sms_url = 'http://site24.way2sms.com/smstoss.action?'
	#send_sms_data = 'ssaction=ss&Token='+jession_id+'&mobile='+number+'&message='+message+'&msgLen=136'

	#send_sms_data = send_sms_data.encode('utf-8')

	#opener.addheaders = [('Referer', 'http://site25.way2sms.com/sendSMS?Token='+jession_id)]

	#try:
	#	sms_sent_page = opener.open(send_sms_url,send_sms_data)
	#except IOError:
	#	print ("Error while sending message")


	#fromaddr = 'testingchunk@gmail.com'
	#toaddrs  = str(request.POST["email"])



# 	container = MIMEBase('multipart', 'mixed', boundary='BOUNDARY')

	#msg = "\r\n".join([
  	#"From: testingchunk@gmail.com",
  	#"To:" +toaddrs,
  	#"Subject:Confirmation email",
  	#"",
  	#email_OTP
  	#])

# 	container.attach(msg)

# 	container['Subject'] = 'Confirmation Email'
	#username = 'testingchunk@gmail.com'
	#password = 'ghostfreak'
	#server = smtplib.SMTP('smtp.gmail.com:587')
	#server.ehlo()
	#server.starttls()
	#server.login(username,password)
	#server.sendmail(fromaddr, toaddrs, msg)
	#server.quit()

	#db = OTP(mobile_number = number , email_id = toaddrs ,  sms = sms_OTP , email = email_OTP)
	#db.save()'''


	return render(request,"train_otp.html",{})




def verify_hire(request):
	request.session["inst_name"] = request.POST["inst_name"]
	request.session["coord_name"] = request.POST["coord_name"]
	request.session["phone"] = request.POST["phone"]
	request.session["email"] = request.POST["email"]
	request.session["hire"] = "true"
	request.session["role"] = request.POST["role"]
	# request.session["experience"] = request.POST["experience"]
	# request.session["language"] = request.POST["language"]
	# request.session["date"] = request.POST["date"]
	# request.session["city"] = request.POST["city"]
	# request.session["address"] = request.POST["address"]

    #r = random.randint(1111,9999)
	#sms_OTP = str(r)

	#r = random.randint(1111,9999)
	#email_OTP = str(r)

# 	username = "9962734053"
# 	passwd = "ghostfreak"
	#message = sms_OTP
	#number = request.POST["phone"]

# 	message = "+".join(message.split(' '))

# 	url = 'http://site24.way2sms.com/Login1.action?'
# 	data = 'username='+username+'&password='+passwd+'&Submit=Sign+in'
# 	data = data.encode('utf-8')

# 	cj = cookielib.CookieJar()
# 	opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))

# 	opener.addheaders = [('User-Agent','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.120 Safari/537.36')]

# 	try:
# 	    usock = opener.open(url, data)
# 	except IOError:
# 	    print ("Error while logging in.")
# 	    sys.exit(1)


# 	jession_id = str(cj).split('~')[1].split(' ')[0]
# 	send_sms_url = 'http://site24.way2sms.com/smstoss.action?'
# 	send_sms_data = 'ssaction=ss&Token='+jession_id+'&mobile='+number+'&message='+message+'&msgLen=136'

# 	send_sms_data = send_sms_data.encode('utf-8')

# 	opener.addheaders = [('Referer', 'http://site25.way2sms.com/sendSMS?Token='+jession_id)]

# 	try:
# 		sms_sent_page = opener.open(send_sms_url,send_sms_data)
# 	except IOError:
# 		print ("Error while sending message")


# 	fromaddr = 'testingchunk@gmail.com'

#	toaddrs  = str(request.POST["email"])



# # 	container = MIMEBase('multipart', 'mixed', boundary='BOUNDARY')

# 	msg = "\r\n".join([
#   	"From: testingchunk@gmail.com",
#   	"To:" +toaddrs,
#   	"Subject:Confirmation email",
#   	"",
#   	email_OTP
#   	])

# # 	container.attach(msg)

# 	container['Subject'] = 'Confirmation Email'
# 	username = 'testingchunk@gmail.com'
# 	password = 'ghostfreak'
# 	server = smtplib.SMTP('smtp.gmail.com:587')
# 	server.ehlo()
# 	server.starttls()
# 	server.login(username,password)
# 	server.sendmail(fromaddr, toaddrs, msg)
# 	server.quit()

	#db = OTP(mobile_number = number , email_id = toaddrs ,  sms = sms_OTP , email = email_OTP)
	#db.save()'''


	return render(request,"hire_otp.html",{})	


def train_registration(request):

	number = request.session["phone"]
	#emailId = OTP.objects.values_list("email_id").filter(mobile_number = number)


	# request.session["first_name"] = request.POST["first_name"]
	# request.session["last_name"] = request.POST["last_name"]
	# request.session["phone"] = request.POST["phone"]
	# request.session["email"] = request.POST["email"]
	request.session["train"] = "true"
	request.session["skills"] = request.POST["skills"]
	request.session["experience"] = request.POST["experience"]
	request.session["language"] = request.POST["language"]
	request.session["date"] = request.POST["date"]
	request.session["city"] = request.POST["pref_loc"]
	request.session["address"] = request.POST["address"]

	# ob = User_info(first_name = request.session["first_name"] ,last_name = request.session["last_name"] , mobile_number = number , email_id = emailId , skills = request.session["skills"], experience = request.session["experience"] , language = request.session["language"] , birthdate = request.session["date"], city = request.session["city"] , address = request.session["address"] , user_name = request.POST["username"] , password = request.POST["password"])

	# ob = User_info(first_name = request.session["first_name"] ,last_name = request.session["last_name"] , mobile_number = number , email_id = emailId , skills = request.POST["skills"], experience = request.POST["experience"] , language = request.POST["language"] , birthdate = request.POST["date"],  address = request.POST["address"] , user_name = request.POST["username"] , password = request.POST["password"])
	# ob.save()

	# user = User.objects.create_user(username= request.POST["username"],password=request.POST["password"])
	# user.save()

	return render(request,"train_user.html",{})



def hire_registration(request):

	# number = request.session["phone"]
	# emailId = OTP.objects.values_list("email_id").filter(mobile_number = number)


	# request.session["first_name"] = request.POST["first_name"]
	# request.session["last_name"] = request.POST["last_name"]
	# request.session["phone"] = request.POST["phone"]
	# request.session["email"] = request.POST["email"]
	request.session["role"] = request.POST["role"]
	# request.session["skills"] = request.POST["skills"]
	request.session["date"] = request.POST["date"]
	request.session["coord_name"] = request.POST["coord_name"]
	# request.session["address"] = request.POST["address"]

	# ob = User_info(first_name = request.session["first_name"] ,last_name = request.session["last_name"] , mobile_number = number , email_id = emailId , skills = request.session["skills"], experience = request.session["experience"] , language = request.session["language"] , birthdate = request.session["date"], city = request.session["city"] , address = request.session["address"] , user_name = request.POST["username"] , password = request.POST["password"])

	# ob = User_info(first_name = request.session["first_name"] ,last_name = request.session["last_name"] , mobile_number = number , email_id = emailId , skills = request.POST["skills"], experience = request.POST["experience"] , language = request.POST["language"] , birthdate = request.POST["date"],  address = request.POST["address"] , user_name = request.POST["username"] , password = request.POST["password"])
	# ob.save()

	# user = User.objects.create_user(username= request.POST["username"],password=request.POST["password"])
	# user.save()

	return render(request,"hire.html",{})	




def train_createuser(request):
	
	# number = request.session["phone"]
	# emailId = OTP.objects.values_list("email_id").filter(mobile_number = number)
	# skills= request.session["skills"] , birthdate = request.session["date"],experience = request.session["experience"] , language = request.session["language"] , city = request.session["city"] ,
	# ob = User_info(first_name = request.session["first_name"] ,last_name = request.session["last_name"] , mobile_number = number ,  email_id = emailId , user_name = request.POST["username"] , password = request.POST["password"])
	ob = Trainer_info(
		first_name = request.session["first_name"] , 
		last_name = request.session["last_name"] ,
		mobile_number = request.session["phone"],  
		email_id = request.session["email"] , 
		user_name = request.user.username , 
		
		experience = "None",
		language = "None",
		birthdate = "None",
		city = "None",
		Description = "None",
		Twitter = "None",
		LinkedIn = "None",
		Country = "None",
		Skype = "None",
		isoftid = "None",
		address = "None",
		skills = "None"
			
	)
	# ob = User_info(first_name = request.session["first_name"] ,last_name = request.session["last_name"] , mobile_number = number , email_id = emailId ,  user_name = request.POST["username"] , password = request.POST["password"])
	ob.save()

		# user = User.objects.create_user(username= request.POST["username"],password=request.POST["password"])
		# user.save()

	return redirect('trainerdash')

def hire_createuser(request):

	# number = request.session["phone"]
	# emailId = OTP.objects.values_list("email_id").filter(mobile_number = number)

	# ob = Hire_user(coord_name = request.session["coord_name"] , mobile_number = number , email_id = emailId , birthdate = request.session["date"] , user_name = request.POST["username"] , password = request.POST["password"])
	ob = Hire_user(role = "None",
		coord_name = "None" ,
		 mobile_number = "Enter Mobile Number" , email_id = "Enter Email ID" ,
		 user_name = request.user.username ,
		  
		  inst_name = "None",
		  
		  isoftid = "None",
		  LinkedIn = "None",
		  Twitter = "None",
		  state = "None",
		  rating=0,
		  count = 0)
	# ob = User_info(first_name = request.session["first_name"] ,last_name = request.session["last_name"] , mobile_number = number , email_id = emailId ,  user_name = request.POST["username"] , password = request.POST["password"])
	ob.save()

	# user = User.objects.create_user(username= request.POST["username"],password=request.POST["password"])
	# user.save()

	# return render(request,"login.html",{})
	return redirect('hiredash')


def validate(request):
# 	number = request.session["phone"]

# 	email_otp = OTP.objects.values_list("email").filter(mobile_number = number)
# 	sms_otp = OTP.objects.values_list("sms").filter(mobile_number = number)
# 	email_otp = list(email_otp[0])
# 	sms_otp = list(sms_otp[0])

# 	if request.POST["phone"] == sms_otp[0] and request.POST["email"] == email_otp[0] and "train" in request.session:
 return TemplateResponse(request,"train.html",{})
	
# 	if request.POST["phone"] == sms_otp[0] and request.POST["email"] == email_otp[0] and "hire" in request.session:
# 		return TemplateResponse(request,"train_req.html",{})		

# 	return TemplateResponse(request,"otp.html",{'status':'retry'})




def train_validate(request):
	#try:
		#number = request.session["phone"]

		#email_otp = OTP.objects.values_list("email").filter(mobile_number = number)
		#sms_otp = OTP.objects.values_list("sms").filter(mobile_number = number)
		#email_otp = list(email_otp[0])
		#sms_otp = list(sms_otp[0])

		#if request.POST["phone"] == sms_otp[0] and request.POST["email"] == email_otp[0] :
 return TemplateResponse(request,"train_profile.html",{})
		#return TemplateResponse(request,"train_otp.html",{'status':'retry'})			
	
	#except:			
	#	return TemplateResponse(request,"train_profile.html",{'status':"Username Already Taken"})



def hire_validate(request):
	number = request.session["phone"]

	#email_otp = OTP.objects.values_list("email").filter(mobile_number = number)
	#sms_otp = OTP.objects.values_list("sms").filter(mobile_number = number)
	#email_otp = list(email_otp[0])
	#sms_otp = list(sms_otp[0])

	#if request.POST["phone"] == sms_otp[0] and request.POST["email"] == email_otp[0] :
	return TemplateResponse(request,"hire_user.html",{})
	

#	return TemplateResponse(request,"hire_otp.html",{'status':'retry'})	


def userValidate(request):
	user = authenticate(username= request.POST["username"],password=request.POST["password"])



	if user is not None:
		if user.is_active:
			if request.POST["username"] == "admin1":
				return redirect('adminpanel')
			# return render(request,"dashboard.html",{'username':user})
			name = Hire_user.objects.all().filter(user_name = user)
			if not name:
				name = User_info.objects.all().filter(user_name = user)
				login(request,user)
				request.session['trainer_name'] = str(name)
				return redirect('trainerdash') 
			else:
				login(request,user)
				request.session['coord_name'] = str(name)
				return redirect('hiredash') 
	else:
		return TemplateResponse(request,"landingpage.html",{'status':"retry"})


def registration(request):
	return render(request,".html",{})



# def user_login(request):
# 	return render(request,"login.html",{})
# {'username':request.session["first_name"]}
def trainer(request):
	username = request.user.username
	name = Trainer_info.objects.all().filter(user_name = username)
	invoices = Invoice.objects.filter(User = request.user.username)
	try:
		rate = int(name[0].rating/name[0].count)
	except:
		rate = 0		
	if not name.exists():
		return redirect('hiredash')
	# ob = post.objects.all()

	skills = Trainer_Skills.objects.all().filter(user_name = username)
	skill = Trainer_Skills.objects.values_list('skill',flat=True).filter(user_name = username)
	requirements = RequirementsPosts.objects.all().filter(skills__in = list(skill))
	nopost = ""
	if requirements.count() == 0:
		nopost = "No Activity yet"
	allskills = Skills.objects.values_list()
	testimonials = Testimonials.objects.all().filter(user_name = username).order_by('-id')[:5]
	notest = ""
	if requirements.count() == 0:
		notest = "No Testimonials yet"
	interests = Interests.objects.values_list('postid',flat=True).filter(trainer_user_name = username)
	interests = list(map(int,interests))
	hired = Interests.objects.filter(trainer_user_name = username , status = "hired")
	history = ""
	job = JobHistory.objects.filter(trainer_user_name = request.user.username)
	if job.count() == 0:
		history = "Hurry! Signup for a job ! "
	try:
		key = Trainer_keys.objects.all().filter(user_name = username).order_by('-user_name')[0]
	except:
		key = "no"		
	today = datetime.date.today()				
	invc = Invoice.objects.filter(User = request.user.username).count()
	invid = invc + 1
	return render(request,"trainer_dashboard.html",
		{'username':username,'trainer':name,
		'skills':skills,'allskills':allskills,
		'requirements':requirements,'key':key,
		'testimonials':testimonials,
		'interests':interests,
		'job':job,
		'hired':hired,
		'stars':range(rate),
		'nopost':nopost,
		'notest':notest,
		'history':history,
		'today':today,
		'invid':invid,
		'invc':invc,
		'invoices':invoices})	
# 'username':request.session["coord_name"].username
def hire(request):
	hirename = request.user
	ob = Interests.objects.filter((Q(status = "requested") | Q(status = "open")),user_name = hirename.username )

	

	pcount = proposals.objects.all().filter(hire_name = hirename.username).count()

	hire = Hire_user.objects.all().filter(user_name = hirename.username)
	hcount = RequirementsPosts.objects.all().filter(user_name = hirename.username).count

	requirements = RequirementsPosts.objects.all().filter(user_name = hirename.username)

	uninterested = RequirementsPosts.objects.all().values_list("postid",flat=True).filter(user_name = hirename.username).exclude(postid__in = ob)

	# for ob2 in requirements:
	# 	print(ob2.postid)
	# 	for interest in ob:
	# 		print(interest.postid)
	# 		if ob2.postid == interest.postid:
	# 			print(ob2.postid)

	try:
		rate = int(name[0].rating/name[0].count)
	except:
		rate = 0
	
	stats = {}
	percentage = []
	keys = []
	# print(ob.count())
	tot = ob.count()
	
	for ui in uninterested:
		stats[str(ui)] = 0

	
	for interest in ob:
		if str(interest.postid) in stats:
			stats[str(interest.postid)] += 1
		else:
			stats[str(interest.postid)] = 1
	
	# print(type(stats))

	for key in stats:
		try:
			stats[key] = int(stats[key]/tot * 100)
			keys.append(key)
			percentage.append(stats[key])
		except:
			pass			
		
	
	stats = zip(keys,percentage)
	print(stats)

	allskills = Skills.objects.all()


	return render(request,"hire_dashboard.html",{'rate':int(rate),'stars':range(rate),'stats':stats,'interests':ob,'hire':hire,'hcount':hcount,'requirements':requirements,'allskills':allskills})		

def postreq(request):
	# user = request.user
	# log_name = Hire_user.objects.filter(user_name = request.user.username).values_list('first_name')

	# ob = post(requirement = request.POST['req'] , name = request.user.username)
	# ob.save()
	return render(request,"train_req.html",{})		


def propose(request):
	ob = post.objects.all()

	for name in ob:
		# print(name.name)
		if name.requirement in request.POST:
			log_name = request.user
			trainer = User_info.objects.all().filter(user_name = log_name.username)
			proposal = proposals(first_name = trainer[0].first_name, last_name = trainer[0].last_name , mobile_number = trainer[0].mobile_number ,email_id = trainer[0].email_id , requirement = name.requirement , hire_name = name.name)
			proposal.save()
			ob = post.objects.all()
			return render(request,"trainer_dashboard.html",{'post':ob})


	return HttpResponse("sd")						
def user_logout(request):
	# user = request.user
	logout(request)
	return redirect("isoft-index")



def ui(request):
	return render(request,"ui.html")	



def skills(request):
	# browser = mechanicalsoup.Browser(soup_config={"features":"html.parser"})
	# page = browser.get("http://planmytrainings.com/projects/")

	# soup = BeautifulSoup(page.text,"html.parser")

	# categories = soup.find("div",{"id":"refine-categories"})	

	# skill = categories.find_all("label",{"class":"selectit"})

	# for label in skill:
	# 	ob = Skills(skill = label.getText())
	# 	ob.save()

	# return HttpResponse(skill)

	name = request.user.username
	ob = Trainer_Skills(skill = request.POST["skill"] ,proficiency = request.POST["proficiency"], user_name = name)
	ob.save()

	# userid = str(request.user.id)
	return redirect("trainerdash")	
	# return HttpResponse(userid)

def updateprofile(request):
	ob = Trainer_info.objects.get(user_name = request.user.username)
	if "address" in request.POST:
		ob.address = request.POST["address"]
	if "description" in request.POST:		
		ob.Description = request.POST["description"]
	if "profession" in request.POST:		
		ob.profession = request.POST["profession"]
	z=""
	if len(str(request.user.id)) < 5:
		for i in range(0,5-len(str(request.user.id))):
			z += "0"

	ob.isoftid = "FT"+z+str(request.user.id )

	if 'twitter' in request.POST:
		ob.Twitter = request.POST["twitter"]		
	if 'linkedin' in request.POST:
		ob.LinkedIn = request.POST["linkedin"]
	if 'skype' in request.POST:
		ob.Skype = request.POST["skype"]
	
	if 'experience' in request.POST:
		ob.experience = request.POST["experience"]		
	
	if 'phone' in request.POST:
		ob.mobile_number = request.POST["phone"]		

	
	if 'email' in request.POST:
		ob.email_id = request.POST["email"]		


	form = ImageUploadForm(request.POST, request.FILES)
	if form.is_valid():
            ob.image = form.cleaned_data['image']
	ob.save()

	# if "skill" in request.POST and request.POST["skill"] != "":
	# 	ob = Trainer_Skills( skill = request.POST["skill"],
	# 		proficiency = request.POST["proficiency"],
	# 		user_name = request.user.username
	# 		)
	# 	ob.save()
	
	
	return redirect("trainerdash")	

def addskill(request):
	

	if "skill" in request.POST and request.POST["skill"] != "":
		ob = Trainer_Skills( skill = request.POST["skill"],
			proficiency = request.POST["proficiency"],
			user_name = request.user.username
			)
		ob.save()
	
	
	return redirect("trainerdash")	


def dummy(request):
	name = request.user.username
	hire = Hire_user.objects.all().filter(user_name = name)
	return render(request,"hire_dashboard.html",{'hire':hire})	



def updatehirer(request):
	ob = Trainer_info.objects.get(user_name = request.user.username)
	if "address" in request.POST:
		ob.address = request.POST["address"]
	if "description" in request.POST:		
		ob.Description = request.POST["description"]
	if "profession" in request.POST:		
		ob.profession = request.POST["profession"]
	ob.isoftid = "FT"+str(request.user.id )

	if 'twitter' in request.POST:
		ob.Twitter = request.POST["twitter"]		
	if 'linkedin' in request.POST:
		ob.LinkedIn = request.POST["linkedin"]
	if 'skype' in request.POST:
		ob.Skype = request.POST["skype"]
	
	if 'experience' in request.POST:
		ob.experience = request.POST["experience"]		
	
	if 'phone' in request.POST:
		ob.mobile_number = request.POST["phone"]		

	
	if 'email' in request.POST:
		ob.email_id = request.POST["email"]		

	form = ImageUploadForm(request.POST, request.FILES)
	if form.is_valid():
            ob.image = form.cleaned_data['image']
	ob.save()
    
	# if "skill" in request.POST:
	# 	name = request.user.username
	# 	ob = Trainer_Skills(skill = request.POST["skill"] ,proficiency = request.POST["proficiency"], user_name = name)
	# 	ob.save()
	
	return redirect("trainerdash")	
	# return HttpResponse(request.FILES["image"])	


def updateHireprofile(request):
	ob = Hire_user.objects.get(user_name = request.user.username)
		
	z=""
	if len(str(request.user.id)) < 5:
		for i in range(0,5-len(str(request.user.id))):
			z += "0"
	ob.isoftid = "FH"+z+str(request.user.id )

	if 'twitter' in request.POST:
		ob.Twitter = request.POST["twitter"]		
	if 'linkedin' in request.POST:
		ob.LinkedIn = request.POST["linkedin"]
	if 'skype' in request.POST:
		ob.Skype = request.POST["skype"]
	
	
	if 'email' in request.POST:
		ob.email_id = request.POST["email"]				
	if 'address' in request.POST:
		ob.institute_address = request.POST["address"]

	if 'role' in request.POST:
		ob.role = request.POST["role"]					

	if 'coord_name' in request.POST:
		ob.coord_name = request.POST["coord_name"]	

	if 'inst_name' in request.POST:
		ob.inst_name = request.POST["inst_name"]			

	form = ImageUploadForm(request.POST, request.FILES)
	if form.is_valid():
            ob.image = form.cleaned_data['image']
	ob.save()
    
	# if "skill" in request.POST:
	# 	name = request.user.username
	# 	ob = Trainer_Skills(skill = request.POST["skill"] ,proficiency = request.POST["proficiency"], user_name = name)
	# 	ob.save()
	
	return redirect("hiredash")		

def updateRequirements(request):
	hire = request.user.username
	ob = RequirementsPosts(no_of_days = request.POST["no_of_days"],
		no_of_students = request.POST["no_of_students"],
		no_of_students_batch = request.POST["no_of_students_batch"],
		no_of_trainers = request.POST["no_of_trainers"],
		materials = request.POST["materials"],		
		tna_pta = request.POST["tna_pta"],
		user_name = hire,
		training = request.POST["training_type"],
		skills = request.POST["skill"])	
		
	ob.save()
	
	return redirect("hiredash")		


def signup(request):
	return render(request,"registration.html",{})





def verifyUser(request):
	request.session["first_name"] = request.POST["first_name"]
	request.session["last_name"] = request.POST["last_name"]
	request.session["phone"] = request.POST["phone"]
	request.session["email"] = request.POST["email"]
	
	# request.session["skills"] = request.POST["skills"]
	# request.session["experience"] = request.POST["experience"]
	# request.session["language"] = request.POST["language"]
	# request.session["date"] = request.POST["date"]
	# request.session["city"] = request.POST["city"]
	# request.session["address"] = request.POST["address"]

	#r = random.randint(1111,9999)
	#sms_OTP = str(r)

	#r = random.randint(1111,9999)
	#email_OTP = str(r)

	#username = "9962734053"
	#passwd = "ghostfreak"
	#message = sms_OTP
	#number = request.POST["phone"]

	#message = "+".join(message.split(' '))

	#url = 'http://site24.way2sms.com/Login1.action?'
	#data = 'username='+username+'&password='+passwd+'&Submit=Sign+in'
	#data = data.encode('utf-8')

	
	#cj = cookielib.CookieJar()
	#opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))

	#opener.addheaders = [('User-Agent','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.120 Safari/537.36')]

	#try:
	#    usock = opener.open(url, data)
	#except IOError:
	#    print ("Error while logging in.")
	#    sys.exit(1)


	#jession_id = str(cj).split('~')[1].split(' ')[0]
	#send_sms_url = 'http://site24.way2sms.com/smstoss.action?'
	#send_sms_data = 'ssaction=ss&Token='+jession_id+'&mobile='+number+'&message='+message+'&msgLen=136'

	#send_sms_data = send_sms_data.encode('utf-8')

	#opener.addheaders = [('Referer', 'http://site25.way2sms.com/sendSMS?Token='+jession_id)]

	#try:
	#	sms_sent_page = opener.open(send_sms_url,send_sms_data)
	#except IOError:
	#	print ("Error while sending message")


	#fromaddr = 'testingchunk@gmail.com'
	#toaddrs  = str(request.POST["email"])



# 	container = MIMEBase('multipart', 'mixed', boundary='BOUNDARY')

	#msg = "\r\n".join([
  	#"From: testingchunk@gmail.com",
  	#"To:" +toaddrs,
  	#"Subject:Confirmation email",
  	#"",
  	#email_OTP
  	#])

# 	container.attach(msg)

# 	container['Subject'] = 'Confirmation Email'
	# username = 'testingchunk@gmail.com'
	# password = 'ghostfreak'
	# server = smtplib.SMTP('smtp.gmail.com:587')
	# server.ehlo()
	# server.starttls()
	# server.login(username,password)
	# server.sendmail(fromaddr, toaddrs, msg)
	# server.quit()

	#db = OTP(mobile_number = number , email_id = toaddrs ,  sms = sms_OTP , email = email_OTP)
	#db.save()'''

	return render(request,"account_registration.html",{})

def validate(request):
	
	#number = request.session["phone"]

		
	#sms_otp = OTP.objects.values_list("sms").filter(mobile_number = number)
		
	#sms_otp = list(sms_otp[0])

	#if request.POST["otp"] == sms_otp[0]  :
		return TemplateResponse(request,"account_registration.html",{})	
#	return TemplateResponse(request,"otp.html",{'status':'retry'})	
	

def createUser(request):
	try:
		user = User.objects.create_user(username= request.POST["username"],password=request.POST["password"])
		user.save()
	except:
		return render(request,"account_registration.html",{'status':'fail'})		
	
	fname = request.session["first_name"]
	phone = request.session["phone"]
	lname = request.session["last_name"]
	email = request.session["email"]

	request.session["username"] = request.POST["username"]
	request.session["password"] = request.POST["password"]
	user = authenticate(username= request.POST["username"],password=request.POST["password"])
	
	login(request,user)

	request.session["first_name"] = fname
	request.session["phone"] = phone
	request.session["last_name"] = lname
	request.session["email"] = email
	

	return render(request,"hireortrain.html",{'username':request.POST["username"],'password':request.POST["password"]})


def adminpanel(request):
	requirement = RequirementsPosts.objects.all()
	allskills = Skills.objects.all()
	employers = Hire_user.objects.all()
	empcount = Hire_user.objects.all().count()
	trainercount = User_info.objects.all().count()
	posts = RequirementsPosts.objects.all().count()
	interests = Interests.objects.values_list()

	interest = Interests.objects.values_list('postid',flat=True)
	req = RequirementsPosts.objects.values_list().filter(postid__in = interest)

	trainer = zip(interests,req)

	
	grievances = Grievances.objects.all()

	return render(request,"adminpanel.html",{'grievances':grievances,'requirements':requirement,'allskills':allskills,'employers':employers,'trainercount':trainercount,'empcount':empcount,'posts':posts,'interests':interests,'traineroverview':trainer})

def clearsearch(request):
	requirement = RequirementsPosts.objects.all()
	allskills = Skills.objects.all()
	employers = Hire_user.objects.all()
	empcount = Hire_user.objects.all().count()
	trainercount = User_info.objects.all().count()
	posts = RequirementsPosts.objects.all().count()
	interests = Interests.objects.values_list()

	interest = Interests.objects.values_list('postid',flat=True)
	req = RequirementsPosts.objects.values_list().filter(postid__in = interest)

	trainer = zip(interests,req)
	
	


	return render(request,"adminpanel.html",{'hire':'true','requirements':requirement,'allskills':allskills,'employers':employers,'trainercount':trainercount,'empcount':empcount,'posts':posts,'interests':interests,'traineroverview':trainer})





def fetchtrainers(request):
	ob = Trainer_Skills.objects.all().filter(skill = request.POST["skill"])

	requirement = RequirementsPosts.objects.all()
	allskills = Skills.objects.all()
	employers = Hire_user.objects.all()
	empcount = Hire_user.objects.all().count()
	trainercount = User_info.objects.all().count()
	posts = RequirementsPosts.objects.all().count()
	interests = Interests.objects.values_list()

	interest = Interests.objects.values_list('postid',flat=True)
	req = RequirementsPosts.objects.values_list().filter(postid__in = interest)

	trainer = zip(interests,req)
	
	


	return render(request,"adminpanel.html",{'trainer':'true','requirements':requirement,'allskills':allskills,'employers':employers,'trainercount':trainercount,'empcount':empcount,'posts':posts,'interests':interests,'traineroverview':trainer,'trainers':ob})

	

def fetchemployers(request):
	ob = Hire_user.objects.all().filter(Q(inst_name__icontains=request.POST["search"]) | Q(coord_name__icontains=request.POST["search"]) | Q(email_id__icontains=request.POST["search"]) | Q(mobile_number__icontains=request.POST["search"]))
	print(ob)
	requirement = RequirementsPosts.objects.all()
	allskills = Skills.objects.all()
	employers = Hire_user.objects.all()
	empcount = Hire_user.objects.all().count()
	trainercount = User_info.objects.all().count()
	posts = RequirementsPosts.objects.all().count()
	return render(request,"adminpanel.html",{'requirements':requirement,'allskills':allskills,'employers':ob,'trainercount':trainercount,'empcount':empcount,'posts':posts,'hire':"true"})


def generate_key(request):
    chars = 'abcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*(-_=+)'
    secret_key = get_random_string(20, chars)
    # cipher = AES.new(secret_key,AES.MODE_ECB) # never use ECB in strong systems obviously
    # encoded = base64.b64encode(cipher.encrypt(msg_text))
    # print(encoded)
    # decoded = cipher.decrypt(baes64.b64decode(msg_text))
    # print(decoded)
    print(hashlib.sha256((secret_key + request.user.username).encode('utf-8')).hexdigest())
    
    ob = Trainer_keys(key = hashlib.sha256((secret_key + request.user.username).encode('utf-8')).hexdigest() ,
     user_name = request.user.username)
    ob.save()

    return redirect("trainerdash")



def showinterest(request):
	

	ob = RequirementsPosts.objects.all().filter(postid = request.POST["interest"])
	interest = Interests(postid = request.POST["interest"],
						 trainer_user_name = request.user.username,
						 user_name = ob[0].user_name)
	interest.save()
	return redirect ('trainerdash')  


def test_regex(request,uri):
	ob = Trainer_keys.objects.all().filter(key = uri)
	trainer = Trainer_info.objects.all().filter(user_name = ob[0].user_name)

	return render(request,"testimonial.html",{'trainer':trainer})

def save_testimonial(request):
	if request.POST["email_id"] == "null" and request.POST["name"] == "null":
		trainer = Trainer_info.objects.all().filter(user_name = request.POST["user_name"])
		return TemplateResponse(request,"testimonial.html",{'trainer':trainer,'status':"retry"})
	ob = Testimonials(testimonial = request.POST["comment"],
					  user_name = request.POST["user_name"],
					  name = request.POST["name"],
					  email_id = request.POST["email_id"])
	ob.save()
	return render(request,"TestimonialSuccess.html",{})	

def fullfilled(request):
	postid = request.POST["interest"]
	ob = Interests.objects.get(postid = str(postid))
	ob.status = "requested"
	ob.save()

	return redirect('trainerdash')	


def viewTrainer(request,username):
	
	name = Trainer_info.objects.all().filter(user_name = username)
	
	try:
		rate = int(name[0].rating/name[0].count)
	except:
		rate = 0		

	skills = Trainer_Skills.objects.all().filter(user_name = username)
	skill = Trainer_Skills.objects.values_list('skill',flat=True).filter(user_name = username)
	requirements = RequirementsPosts.objects.all().filter(skills__in = list(skill))
	allskills = Skills.objects.values_list()
	testimonials = Testimonials.objects.all().filter(user_name = username).order_by('-id')[:5]
	
	
	hirename = request.user
	ob = Interests.objects.filter(user_name = hirename.username)
	hire = Hire_user.objects.all().filter(user_name = hirename.username)		
	job = JobHistory.objects.filter(trainer_user_name = username)
	return render(request,"trainer_profile.html",
		{'username':username,'trainer':name,
		'skills':skills,'allskills':allskills,
		'requirements':requirements,
		'testimonials':testimonials,
		'interests':ob,'hire':hire,
		'job':job,
		'rate':int(rate),
		'stars':range(rate)})	


def job_done(request):
	ob = Interests.objects.filter(postid = request.POST["postid"] , trainer_user_name = request.POST["trainer"])
	job = JobHistory(trainer_user_name = request.POST["trainer"] , hire_user_name =  request.user.username, postid = request.POST["postid"])
	job.save()
	ob.delete()
	req = RequirementsPosts.objects.filter(postid = request.POST["postid"])		
	req.delete()
	

	return redirect('hiredash')	


def hireTrainer(request):
	ob = Interests.objects.get(trainer_user_name = request.POST["trainer"])
	ob.status = "hired"
	ob.save()
	
	return redirect('hiredash')	


def rate(request):
	ob = Trainer_info.objects.get(user_name = request.POST["username"])
	ob.rating += int(request.POST["rate"])
	ob.count += 1
	ob.save()

	
	return HttpResponse(viewTrainer(request,request.POST["username"]))

def tour(request):
	username = request.user.username
	name = Trainer_info.objects.all().filter(user_name = username)
	try:
		rate = int(name[0].rating/name[0].count)
	except:
		rate = 0		
	if not name.exists():
		return redirect('hiredash')
	# ob = post.objects.all()

	skills = Trainer_Skills.objects.all().filter(user_name = username)
	skill = Trainer_Skills.objects.values_list('skill',flat=True).filter(user_name = username)
	requirements = RequirementsPosts.objects.all().filter(skills__in = list(skill))
	allskills = Skills.objects.values_list()
	testimonials = Testimonials.objects.all().filter(user_name = username).order_by('-id')[:5]
	interests = Interests.objects.values_list('postid',flat=True).filter(trainer_user_name = username)
	interests = list(map(int,interests))
	hired = Interests.objects.filter(trainer_user_name = username , status = "hired")
	job = JobHistory.objects.filter(trainer_user_name = request.user.username)
	try:
		key = Trainer_keys.objects.all().filter(user_name = username).order_by('-user_name')[0]
	except:
		key = "no"		
	return render(request,"tour.html",
		{'username':username,'trainer':name,
		'skills':skills,'allskills':allskills,
		'requirements':requirements,'key':key,
		'testimonials':testimonials,
		'interests':interests,
		'job':job,
		'hired':hired,
		'stars':range(rate)})


def issue(request):
	ob = Issue(user_name = request.user.username, issue = request.POST["issue"])
	ob.save()
	return redirect('hiredash')


def grievances(request):

	return render(request,"grievance_verify.html",{})	


def auth_grievance(request):
	user = authenticate(username= request.POST["username"],password=request.POST["password"])

	login(request,user)

	if user is not None:
		if user.is_active:
			return render(request,"grievances.html",{})		

	return render(request,"grievance_verify.html",{'status':'retry'})


def submit_grievance(request):
	if not re.match(r"^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$",request.POST["email_id"]):
		return render(request,"grievances.html",{'status':'email'})

	if not re.match(r"^(\d{10})$",request.POST["mobile_number"]):
		return render(request,"grievances.html",{'status':'mobile'})		
	
	chars = 'abcdefghijklmnopqrstuvwxyz0123456789!@#$%&-_=+'
	secret_key = get_random_string(10, chars)
	print("isofG"+secret_key)

	ob = Grievances(user_name = request.user.username,
					Org_name = request.POST["org_name"],
					Inst_name = request.POST["inst_name"],
					Emp_name = request.POST["emp_name"],
					grievance = request.POST["grievance"],
					first_name = request.POST["first_name"],
					last_name = request.POST["last_name"],
					email_id = request.POST["email_id"],
					mobile_number = request.POST["mobile_number"],
					trackid = "isofG"+secret_key,
					status = "Open"
		 )
	ob.save()
	return render(request,"grievance_status.html",{'trackid':str("isofG"+secret_key),'status':'Open'})	


def grievance_status(request,uri):
	ob = Grievances.objects.all().filter(trackid = str("isofG"+uri))
	return render(request,"grievance_status.html",{'trackid':ob[0].trackid,'status':ob[0].status})	


def rateemp(request):
	ob = Hire_user.objects.get(user_name = request.POST["user_name"])
	ob.rating += int(request.POST["rate"])
	ob.count += 1
	ob.save()

	return redirect('trainerdash')	


def invoice(request):
	if request.POST['invoice_unit_cost'] == "":
		costperday = request.POST['invoice_unit_cost_mob']
	else:
		costperday = request.POST['invoice_unit_cost']

	if request.POST['invoice_quantity'] == "":
		noofdays = request.POST['invoice_quantity_mob']
	else:
		noofdays = request.POST['invoice_unit_cost']



	ob = Invoice(
		User = request.user.username,
		To = "TopFreshers Technologies Pvt. Ltd.",
		Address = "149,Opp DLF",
		Due = request.POST['invoice_due'],
		Unit = costperday,
		Quantity = noofdays,
		Total = request.POST['invoice_total'],
		Discount = request.POST['invoice_discount'],
		Tax = request.POST['invoice_tax'],
		Grand = request.POST['invoice_grand_total'],
		PAN = request.POST['pan'],
		email = request.POST['email'],
		accno = request.POST['accno'],
		accholder = request.POST['accholder'],
		bank = request.POST['bank'],
		ifsc = request.POST['ifsc'],
		Service = request.POST['invoice_desc_head'],
		)	
	ob.save()
	return render(request,"invoice_print_from.html",{
												'ifsc' :request.POST['ifsc'],
												'bank' :request.POST['bank'],
												'accno' :request.POST['accno'],
												'accholder' :request.POST['accholder'],
												'date': request.POST['date'],
												'desc' : request.POST['invoice_desc_head'],
												'from':	request.POST['address'],
												'contact':	request.POST['contact'],
												'pan': request.POST['pan'],
												'email': request.POST['email'],
												'due':request.POST['invoice_due'],
												'unit':request.POST['invoice_unit_cost'],
												'quantity':request.POST['invoice_quantity'],
												'total':request.POST['invoice_total'],
												'ta':request.POST['invoice_discount'],
												'oa':request.POST['invoice_tax'],
												'grand':request.POST['invoice_grand_total']})
	

	return render('trainerdash')
def createInvoice(request):
	today = datetime.date.today()	
	invc = Invoice.objects.filter(User = request.user.username).count()
	invid = invc + 1
	return render(request,"invoice.html",{'today':today,'invid':invid})


def printInvoice(request):
	ob = Invoice.objects.filter(id = int(request.POST['id']))
	return render(request,"invoice_print.html",{'ob':ob})