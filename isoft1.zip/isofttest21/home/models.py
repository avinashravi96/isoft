from django.db import models

# Create your models here.
class User_info(models.Model):
	first_name = models.CharField((u"First Name"),max_length = 10)
	last_name = models.CharField((u"Last Name"),max_length = 10)
	mobile_number = models.CharField((u"Mobile Number"),max_length = 10)
	email_id = models.CharField((u"Email ID"),max_length = 100)
	skills = models.CharField((u"Skills"),max_length = 300)
	experience = models.CharField((u"Experience"),max_length = 10)
	language = models.CharField((u"Language"),max_length = 60)
	birthdate = models.CharField((u"Birthdate"),max_length = 60)
	city = models.CharField((u"City"),max_length = 50)
	address = models.CharField((u"Address"),max_length = 400)
	user_name = models.CharField((u"User Name"),max_length = 200)
	password = models.CharField((u"Password"),max_length = 200)

	def __str__(self):
		return self.first_name+self.last_name+self.mobile_number+self.email_id+self.experience+self.language+self.birthdate+self.city+self.address+self.user_name+self.password
	
	class Meta:
		verbose_name = 'User Info'
		verbose_name_plural = 'User Info'		

class Hire_user(models.Model):
	
	mobile_number = models.CharField((u"Mobile Number"),max_length = 10)
	email_id = models.CharField((u"Email ID"),max_length = 100)
	role = models.CharField((u"Role"),max_length = 300)
	coord_name = models.CharField((u"Coordinator Name"),max_length = 400)
	user_name = models.CharField((u"User Name"),max_length = 200)
	password = models.CharField((u"Password"),max_length = 200)
	inst_name = models.CharField((u"Institute Name"),max_length = 200)
	image =  models.ImageField(upload_to = 'img/', default = 'img/user.jpg')
	institute_address = models.CharField((u"Address"),max_length = 100)
	isoftid = models.CharField((u"ISOFT ID"),max_length = 50)
	LinkedIn = models.CharField((u"LinkedIn URL"),max_length = 50)
	Twitter = models.CharField((u"Twitter URL"),max_length = 50)
	state = models.CharField((u"State"),max_length = 50)
	rating = models.IntegerField((u"Rating"))
	count = models.IntegerField((u"Count"))
	
	

	def __str__(self):
		return self.mobile_number+self.email_id+self.coord_name+self.user_name+self.password+self.inst_name+self.isoftid+self.LinkedIn+self.Twitter+self.state+str(self.rating)

	class Meta:
		verbose_name = 'Hire Info'
		verbose_name_plural = 'Hire Info'		



class OTP(models.Model):
	mobile_number = models.CharField((u"Mobile Number"),max_length = 10)
	email_id = models.CharField((u"Email ID"),max_length = 100)
	sms = models.CharField((u"SMS OTP"),max_length = 10)		
	email = models.CharField((u"Email OTP"),max_length = 10)

	def __str__(self):
		return self.mobile_number+self.email_id+self.sms+self.email

	class Meta:
		verbose_name = 'OTP'
		verbose_name_plural = 'OTP'		

class RequirementsPosts(models.Model):
	no_of_students = models.CharField((u"No of Students"),max_length = 8)
	no_of_trainers = models.CharField((u"No of Trainers"),max_length = 8)
	no_of_students_batch = models.CharField((u"No of Students per Batch"),max_length = 8)
	no_of_days = models.CharField((u"No of Days"),max_length = 8)
	materials = models.CharField((u"Need of Materials"),max_length = 3)
	tna_pta = models.CharField((u"TNA PTA Required"),max_length = 3)
	user_name = models.CharField((u"User Name"),max_length = 200)
	training = models.CharField((u"Training Type"),max_length = 3)
	posted = models.DateTimeField(auto_now_add=True)
	postid = models.AutoField(primary_key=True)
	skills = models.CharField((u"Skills"),max_length = 50)

	def __str__(self):
		return self.no_of_trainers+self.no_of_days+self.no_of_students+self.training+self.no_of_students_batch+self.materials+self.tna_pta+self.user_name+self.skills+" | "+str(self.postid)+"   |  "+str(self.posted)
	
	class Meta:
		verbose_name = 'Requirements Posts'
		verbose_name_plural = 'Requirements Posts'		

class proposals(models.Model):
	
	first_name = models.CharField((u"First Name"),max_length = 10)
	last_name = models.CharField((u"Last Name"),max_length = 10)
	mobile_number = models.CharField((u"Mobile Number"),max_length = 10)
	email_id = models.CharField((u"Email ID"),max_length = 100)
	requirement = models.CharField((u"Requirement"),max_length = 200)
	hire_name = models.CharField((u"Hire Name"),max_length = 200)

	def __str__(self):
		return self.requirement+self.first_name+self.last_name+self.email_id+self.mobile_number+self.hire_name

	class Meta:
		verbose_name = 'Proposal'
		verbose_name_plural = 'Proposal'		

class Trainer_info(models.Model):
	first_name = models.CharField((u"First Name"),max_length = 10)
	last_name = models.CharField((u"Last Name"),max_length = 10)
	mobile_number = models.CharField((u"Mobile Number"),max_length = 10)
	email_id = models.CharField((u"Email ID"),max_length = 100)
	skills = models.CharField((u"Skills"),max_length = 300 )
	experience = models.CharField((u"Experience"),max_length = 10 )
	language = models.CharField((u"Language"),max_length = 60)
	birthdate = models.CharField((u"Birthdate"),max_length = 60)
	city = models.CharField((u"City"),max_length = 50)
	user_name = models.CharField((u"User Name"),max_length = 200)
	password = models.CharField((u"Password"),max_length = 200)
	isoftid = models.CharField((u"ISOFT ID"),max_length = 50)
	Description = models.CharField((u"Trainer Description"),max_length = 50)
	LinkedIn = models.CharField((u"LinkedIn URL"),max_length = 50)
	Twitter = models.CharField((u"Twitter URL"),max_length = 50)
	Country = models.CharField((u"Country"),max_length = 50,default = "India")
	Skype = models.CharField((u"Skype ID"),max_length = 50)
	address = models.CharField((u"Address"),max_length = 50)
	profession = models.CharField((u"Profession"),max_length = 50)
	image =  models.ImageField(upload_to = 'img/', default = 'img/user.jpg')
	rating = models.IntegerField((u"Rating"),null=True)
	count = models.IntegerField((u"Count"),null=True)

	def __str__(self):
		return self.first_name+self.last_name+self.mobile_number+self.email_id+self.experience+self.language+self.birthdate+self.city+self.address+self.user_name+self.password+self.isoftid+self.profession+str(self.count)
	
	class Meta:
		verbose_name = 'Trainers Info'
		verbose_name_plural = 'Trainers Info'		

class Skills(models.Model):
	skill = models.CharField((u"Skills"),max_length = 100)

	def __str__(self):
		return self.skill


	class Meta:
		verbose_name = 'Skills'
		verbose_name_plural = 'Skills'	

class Trainer_Skills(models.Model):
	skill = models.CharField((u"Skills"),max_length = 100)
	proficiency = models.CharField((u"Proficiency"),max_length = 100)
	user_name = models.CharField((u"User Name"),max_length = 100)


	def __str__(self):
		return self.skill+self.user_name


	class Meta:
		verbose_name = 'Trainer Skills'
		verbose_name_plural = 'Trainer Skills'


class Trainer_keys(models.Model):
	key = models.CharField((u"Key"),max_length = 200)
	user_name = models.CharField((u"User Name"),max_length = 100)

	def __str__(self):
		return self.key+self.user_name


	class Meta:
		verbose_name = 'Trainer Keys'
		verbose_name_plural = 'Trainer Keys'



class Interests(models.Model):
	postid = models.CharField((u"Post Id"),max_length = 200)
	user_name = models.CharField((u"User Name"),max_length = 100)
	trainer_user_name = models.CharField((u"Trainer User Name"),max_length = 100)
	status = models.CharField((u"Status"),max_length = 100)
	posted = models.DateTimeField(auto_now_add=True)

	def __str__(self):
		return self.postid+self.user_name+self.trainer_user_name+self.status+" | "+str(self.posted)


	class Meta:
		verbose_name = 'Interests'
		verbose_name_plural = 'Interests'	


class Testimonials(models.Model):
	testimonial = models.CharField((u"Testimonial"),max_length = 200)
	user_name = models.CharField((u"User Name"),max_length = 100)
	userid = models.CharField((u"ID"),max_length = 100)
	name = models.CharField((u"Name"),max_length = 100)
	email_id = models.CharField((u"Email ID"),max_length = 100)

	def __str__(self):
		return self.testimonial+self.user_name+self.userid+self.name+self.email_id


	class Meta:
		verbose_name = 'Testimonials'
		verbose_name_plural = 'Testimonials'			



class JobHistory(models.Model):
	trainer_user_name = models.CharField((u"Trainer User Name"),max_length = 100)
	hire_user_name = models.CharField((u"Hire User Name"),max_length = 100)
	postid = models.CharField((u"Post ID"),max_length = 100)
	posted = models.DateTimeField(auto_now_add=True)

	def __str__(self):
		return self.trainer_user_name+self.hire_user_name+self.postid+" | "+str(self.posted)

	class Meta:
		verbose_name = "Job History"
		verbose_name_plural = "Job History"		

class Issue(models.Model):
	
	user_name = models.CharField((u"User Name"),max_length = 100)
	issue = models.CharField((u"Issue"),max_length = 100)
	posted = models.DateTimeField(auto_now_add=True)
	

	def __str__(self):
		return self.user_name+self.issue+" | "+str(self.posted)

	class Meta:
		verbose_name = "Issues"
		verbose_name_plural = "Issues"		


class Grievances(models.Model):
	
	user_name = models.CharField((u"User Name"),max_length = 100)
	Org_name = models.CharField((u"Organization Name"),max_length = 100)
	Inst_name = models.CharField((u"Institute Name"),max_length = 100)
	Emp_name = models.CharField((u"Employer Name"),max_length = 100)
	grievance = models.CharField((u"Grievance "),max_length = 300)
	first_name = models.CharField((u"First Name"),max_length = 100)
	last_name = models.CharField((u"Last Name"),max_length = 100)
	email_id = models.CharField((u"Email ID"),max_length = 100)
	mobile_number = models.CharField((u"Mobile Number"),max_length = 100)
	posted = models.DateTimeField(auto_now_add=True)
	trackid = models.CharField((u"Track ID"),max_length = 100)
	status = models.CharField((u"Status"),max_length = 15)

	def __str__(self):
		return self.user_name+self.Org_name+self.Inst_name+self.Emp_name+self.grievance+self.first_name+self.last_name+self.email_id+self.mobile_number+self.trackid+self.status+" | "+str(self.posted)

	class Meta:
		verbose_name = "Grievances"
		verbose_name_plural = "Grievances"	


class Notification(models.Model):
	user_name = models.CharField((u"User Name"),max_length = 100)
	hire_user_name = models.CharField((u"Employer User Name"),max_length = 100)
	postid = models.CharField((u"Post Id"),max_length = 200)

	def __str__(self):
		return self.user_name+self.hire_user_name+self.postid

	class Meta:
		verbose_name = "Notifications"
		verbose_name_plural = "Notifications"	



	


		

class Invoice(models.Model):

	User = models.CharField(max_length=100)
	To = models.CharField(max_length=100)
	Due = models.CharField(max_length=100)
	Address = models.CharField(max_length=300)
	Service = models.CharField(max_length=100)
	Unit = models.CharField(max_length=100)
	Quantity = models.CharField(max_length=100)
	Total = models.CharField(max_length=100)
	Discount = models.CharField(max_length=100)
	Tax = models.CharField(max_length=100)
	Grand = models.CharField(max_length=100)
	PAN = models.CharField(max_length=100)
	email = models.CharField(max_length=100)
	updated_at = models.DateTimeField(auto_now=True)
	accno = models.CharField(max_length=100)
	accholder = models.CharField(max_length=200)
	bank = models.CharField(max_length=200)
	ifsc = models.CharField(max_length=100)


	def __str__(self):
		return self.User+self.To+self.Due+self.Address+self.Service+self.Grand+self.Discount+self.Tax+self.PAN+self.email+str(self.updated_at)+self.Unit+self.accno+self.accholder+self.bank+self.ifsc

	class Meta:
		verbose_name_plural = "Invoice"



