from django.apps import AppConfig


class TrainersConfig(AppConfig):
    name = 'home'
